import os
import sys

import pygame

pygame.font.init()


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname).convert()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


class MainWindow:
    def __init__(self):
        self.width, self.height = 500, 500
        self.screen = pygame.display.set_mode((self.width, self.height))
        self.fon = pygame.transform.scale(load_image("fon.jpg", colorkey=-1), (self.width, self.height))
        self.font = pygame.font.Font(None, 30)
        self.text_rendered = self.font.render("Играть", 1, pygame.Color("black"))
        self.text_collide = self.text_rendered.get_rect()
        self.text_collide.x, self.text_collide.y = (10, 50)

    def main_window_running(self):
        flag_to_start_game = True
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEMOTION:
                    pos = event.pos
                    if pos[0] in range(self.text_collide.x, self.text_collide.x + self.text_collide.size[0] + 1) and \
                            pos[1] in range(self.text_collide.y, self.text_collide.y + self.text_collide.size[1] + 1):
                        self.text_rendered = self.font.render("Играть", 1, pygame.Color("grey"))
                        flag_to_start_game = True
                    else:
                        self.text_rendered = self.font.render("Играть", 1, pygame.Color("black"))
                        flag_to_start_game = False
                if event.type == pygame.MOUSEBUTTONDOWN and flag_to_start_game:
                    return True
            self.screen.blit(self.fon, (0, 0))
            self.screen.blit(self.text_rendered, (self.text_collide.x, self.text_collide.y))
            pygame.display.update()


class HeroMove(pygame.sprite.Sprite):
    def __init__(self, screen, tilemap, *all_sprites):
        super().__init__(*all_sprites)
        self.tilemap = tilemap
        self.screen = screen
        self.image = load_image("mar.png", colorkey=-1)
        self.rect = self.image.get_rect()
        self.rect.x = 4 * 50 + 50 // 3.7
        self.rect.y = 4 * 50 + 50 // 8
        self.d = 50

    def update(self, *args, **kwargs):
        if args:
            key = args[0]
            try:
                if key[pygame.K_DOWN] and self.tilemap[(self.rect.y + 50) // 50][self.rect.x // 50] != '#':
                    self.rect.top += self.d
                elif key[pygame.K_UP] and self.tilemap[(self.rect.y - 50) // 50][self.rect.x // 50] != '#':
                    self.rect.top -= self.d
                elif key[pygame.K_LEFT] and self.tilemap[self.rect.y // 50][(self.rect.x - 50) // 50] != '#':
                    self.rect.left -= self.d
                elif key[pygame.K_RIGHT] and self.tilemap[self.rect.y // 50][(self.rect.x + 50) // 50] != '#':
                    self.rect.right += self.d
            except IndexError:
                return


class Game:
    def __init__(self, tilemap):
        self.tilemap = tilemap
        self.screen = pygame.display.set_mode((500, 500))
        self.fps = pygame.time.Clock()
        self.cell_size = 50
        self.all_sprites = pygame.sprite.Group()

    def render(self, scr):
        for x_coord in range(self.screen.get_width() // self.cell_size):
            for y_coord in range(self.screen.get_height() // self.cell_size):
                if self.tilemap[y_coord][x_coord] == '#':
                    self.screen.blit(load_image("box.png"), (x_coord * self.cell_size,
                                                             y_coord * self.cell_size, self.cell_size,
                                                             self.cell_size))
                elif self.tilemap[y_coord][x_coord] == '.':
                    self.screen.blit(load_image("grass.png"), (x_coord * self.cell_size,
                                                               y_coord * self.cell_size, self.cell_size,
                                                               self.cell_size))

    def run(self):
        self.render(self.screen)
        HeroMove(self.screen, self.tilemap, self.all_sprites)
        while True:
            self.screen.fill((0, 0, 0))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                key = pygame.key.get_pressed()
                self.all_sprites.update(key)
            self.render(self.screen)
            self.all_sprites.draw(self.screen)
            pygame.display.update()


flag = MainWindow().main_window_running()
if flag:
    tilemap = list(map(lambda x: " ".join(x.strip()).split(), open(r"maps/tilemap_1.txt", "r", encoding="utf-8").readlines()))
    Game(tilemap).run()
